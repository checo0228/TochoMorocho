# Etiquetas De Tocho Morocho

App web interna para generar etiquetas de precio con código de barras de la tienda **De Tocho Morocho** (importadora, León, Gto.). La usan 2 personas: la dueña (no técnica) y su hijo. Es un proyecto de la tienda, independiente de cualquier agencia.

## Stack
- Next.js (App Router, TypeScript) desplegado en Vercel.
- Supabase: Postgres + Auth (login por correo). Solo 2 usuarios, sin roles.
- PDFs generados **en el navegador** (jsPDF + bwip-js o JsBarcode). Nada de generar PDFs en el servidor.
- UI en español de México. Diseño: seguir el diseño de Claude Design (carpeta `/design` o el enlace que se indique).

## Hardware (ya probado en la tienda)
- Impresora **Zebra ZD220d** (térmica directa, 203 dpi), driver ZDesigner v10 por USB.
- Escáneres: pistola y escáner de bola Honeywell/Metrologic Orbit MK7120 (modo teclado USB: teclean el código + Enter).
- Punto de venta: **Multicomercio** (Windows). La app NO se integra en vivo; solo intercambia archivos Excel.

## Reglas de negocio
- **Los códigos nuevos son solo dígitos.** Los escáneres convierten el guion "-" en apóstrofo "'" con el teclado en español, así que un código con guion nunca se encuentra en caja. Validar `^\d+$` al crear. Existe al menos un código alfanumérico heredado (`901A`), que funciona; aceptar los existentes, pero nunca guion ni símbolos. Normalizar entradas del escáner: quitar espacios y, si llega `'`, avisar.
- Todavía hay códigos con guion en Multicomercio (900-22, 900-34, 900-8, 900-32 y 899-13, este inactivo). En la app se guardan sin guion (`codigo`) y se conserva el original en `codigo_multicomercio`, para avisar que falta corregirlos allá.
- Cada producto tiene tamaño de etiqueta: `grande` o `chica` (o vacío = falta asignar; no se puede imprimir hasta asignarlo).
- `etiqueta_unica = true`: al generar etiquetas por existencia, imprimir solo 1 sin importar la cantidad (productos en exhibidor; los 12 marcados en amarillo por la dueña).
- `no_etiquetar = true`: excluir de las impresiones masivas (anillos, árboles, aretes y pulseras de Bisutería). Sí se puede imprimir uno a mano si se pide explícitamente.
- Producto creado en la app → `pendiente_multicomercio = true` hasta que se exporte y se dé de alta en Multicomercio.
- **Multicomercio reutiliza códigos**: un código viejo puede pasar a ser otro producto (ej. 895 "cepillo perro azul gde" → "serie flores"). Al sincronizar, un cambio de NOMBRE significa producto distinto: marcarlo, avisar que las etiquetas físicas viejas ya no sirven y no sumar la existencia anterior. Un cambio solo de precio = mismo producto, hay que reetiquetar todas sus piezas.

## Modelo de datos (tabla `productos`)
| campo | tipo | nota |
|---|---|---|
| codigo | text PK | solo dígitos |
| nombre | text | puede venir vacío en el catálogo heredado |
| precio | numeric(10,2) | |
| categoria | text | |
| codigo_multicomercio | text | código tal cual está en Multicomercio (puede traer guion) |
| tamano | text | 'grande' \| 'chica' \| null |
| activo | boolean | |
| etiqueta_unica | boolean | default false |
| no_etiquetar | boolean | default false |
| pendiente_multicomercio | boolean | default false |
| updated_at | timestamptz | |

Opcional: tabla `lista_impresion` (codigo, cantidad, usuario) para que la lista sobreviva recargas y se comparta entre los 2 usuarios.

Carga inicial: `data/catalogo.csv` (1,160 productos al 23-oct-2026, con nombres y precios de Multicomercio; 873 grande, 278 chica, 9 sin tamaño; 12 con etiqueta_unica; 19 no_etiquetar). Reemplaza al antiguo `catalogo_inicial.csv`.

Archivos reales de ejemplo para pruebas de los parsers: `data/muestras/` (exportación de productos, compra en PDF, existencias .xls y la lista de productos nuevos que arma la dueña). Contienen costos y precios reales: el repo debe ser privado.

## Pantallas
1. **Login** por correo.
2. **Imprimir** (principal): campo de búsqueda/escaneo siempre enfocado. Código exacto existente + Enter → agrega (o suma 1). Texto → sugerencias por nombre. Código inexistente → abre "Producto nuevo" con el código precargado. Lista con cantidad −/+, chip de tamaño, quitar. Resumen: grandes = N etiquetas; chicas = N etiquetas = ceil(N/3) hileras. Botones "Descargar PDF grandes" y "Descargar PDF chicas".
3. **Producto nuevo**: código, nombre, precio, categoría, tamaño, con vista previa en vivo de la etiqueta. Al guardar: se agrega a la lista y queda pendiente en Multicomercio.
4. **Catálogo**: búsqueda; filtros por categoría, tamaño, sin tamaño, pendientes y activos; edición rápida; "Agregar a impresión".
5. **Sincronizar**: (a) subir el Excel de productos de Multicomercio → mostrar resumen de cambios → aplicar; (b) "Exportar pendientes" a Excel. La plantilla oficial de importación de Multicomercio aún no la tenemos: por ahora exportar columnas código, nombre, precio, categoría, y dejar el formato aislado en una función para cambiarlo después.

## Formatos de Multicomercio (ver `data/muestras/`)
**Productos (Excel).** Las columnas cambian según cómo se exporte, así que **ubicar columnas por el texto del encabezado (fila 0), no por posición**:
- Versión corta: `Artículo | | | Código | Precio 1 | Activo`.
- Versión completa (todo_v2): `Artículo | | | SKU | Código | Se vende por | impuestos | Marca | Proveedor | Precio 1 | Activo | Costo`.
- Filas de categoría: columna B = `Categoría : NOMBRE (COUNT=n)` → extraer NOMBRE.
- Filas de producto: B = nombre (puede ser "." = sin nombre), Código (texto), Precio 1 (puede venir como 62.9999 → redondear a 2 decimales), Activo = "Verdadero"/"Falso".
- La última fila puede traer basura (código sin precio) → ignorar filas sin precio.

**Compra (PDF "COMPRAS POR PROVEEDOR").** Renglones `Cantidad | Código | Artículo | IEPS | IVA | Costo Unit. | Importe`, en varias páginas. Un mismo código puede aparecer en dos renglones (sumar cantidades). Trae costo, NO precio de venta. Fase futura: subir este PDF para generar las etiquetas de la llegada.

**Existencias (.xls).** Es XML SpreadsheetML generado por FastReport, no un Excel binario: código en la columna B, descripción en F/G y existencia en O, agrupado por categoría. Puede traer existencias negativas (tratar como 0).

## Especificación de etiquetas (PROBADA EN LA IMPRESORA, no cambiar sin probar)
Unidades en mm. Origen (0,0) = esquina inferior izquierda de la página (convertir si la librería usa la superior). Código de barras **Code128**, sin texto integrado (el número se dibuja aparte), sin quiet zone añadida por la librería. Ancho de módulo en múltiplos de 0.125 mm (203 dpi).

**Grande — página 38 × 25 mm, 1 etiqueta por página**
- Nombre: Helvetica-Bold 7 pt, centrado, base en y = 25 − 2.7; si no cabe en 35.5 mm de ancho, reducir de 0.25 en 0.25 hasta 4.5 pt. Omitir si el nombre está vacío o es ".".
- Precio: Helvetica-Bold 10.5 pt, centrado, base en y = 25 − 6.6, formato `$ 1,234.00`.
- Barras: alto 12.5 mm, y = 3.0; módulo 0.375 mm, y si el ancho pasa de 33 mm, módulo 0.25 mm. Centrado horizontal.
- Número del código: Helvetica 6 pt, centrado, base en y = 0.8.

**Chica — rollo de 3 por hilera, página 90 × 13 mm, 3 etiquetas por página**
- Etiqueta de 27 × 13 mm en x = 1.5, 31.5 y 61.5 mm (separación de 3 mm).
- Precio: Helvetica-Bold 8 pt, centrado en la etiqueta, base en y = 9.2.
- Barras: alto 5.6 mm, y = 3.0; módulo 0.25 mm (si con 0.375 cabe en ≤ 25.4 mm se puede usar 0.375). Ancho máximo 25.4 mm.
- Número del código: Helvetica 5 pt, base en y = 1.1.
- Sin nombre. Las etiquetas se llenan de izquierda a derecha y de hilera en hilera; la última hilera puede quedar incompleta.

**Configuración del driver de la Zebra (instrucción para el usuario, mostrar en la UI)**
- Grande: Ancho 38 mm, Alto 25 mm, Tipo de medio "Etiquetas con espacios".
- Chica: Ancho 90 mm, Alto 13 mm, "Etiquetas con espacios".
- Imprimir siempre en **Tamaño real** (no "Ajustar"). Calibrar la Zebra al cambiar de rollo (mantener el botón y soltar al 2.º parpadeo).

**Impresión de archivos grandes.** Windows y el driver se atascan con PDFs de más de ~300 páginas (el trabajo se queda en "Impresión" y la Zebra en verde sin hacer nada). La app debe partir las descargas en lotes de máximo 300 páginas (`grandes_cocina_1de4.pdf`, …) o, como mínimo, mostrar los rangos de páginas a imprimir por partes.

## Flujo de llegada de mercancía (como se hace hoy, a automatizar)
1. Llega la compra; se registra en Multicomercio (los productos nuevos casi siempre reutilizan códigos viejos).
2. Se exporta el Excel de productos actualizado.
3. Se comparan con el catálogo de la app: nombres cambiados = producto nuevo, precios cambiados, códigos con guion.
4. Etiquetas a imprimir = cantidades de la compra (+ productos nuevos capturados aparte), con su tamaño. Para los productos con nombre cambiado o precio cambiado que ya estaban etiquetados, reimprimir todas sus piezas.

## Verificación
- Test automatizado: renderizar páginas de muestra a 203 dpi en blanco y negro y decodificar cada código de barras (por ejemplo con zxing) comparando contra el código esperado.
- Casos borde: códigos de 1 a 5 dígitos, nombres de 29+ caracteres, precio con decimales raros, nombre vacío.
